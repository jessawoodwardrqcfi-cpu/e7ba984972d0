// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Build HNSW, M=16");
  std::fflush(stdout);
  return lionss_run_workload("hnswindex");
}
