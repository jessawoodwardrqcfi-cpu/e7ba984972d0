// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Replay at 10x\n", stdout);
  return lionss_run_workload("pktReplayer");
}
