// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Solve mixed-integer model\n", stdout);
  return lionss_run_workload("Cassowary3");
}
