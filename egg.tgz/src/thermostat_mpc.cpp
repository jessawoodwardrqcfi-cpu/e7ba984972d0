// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Model-predictive heating schedule\n", stdout);
  return lionss_run_workload("thermostat_mpc");
}
