// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fan out to 20k sockets"); }
int main(){
  announce();
  return lionss_run_workload("wsFanout");
}
