// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fungal infection risk index"); }
int main(){
  announce();
  return lionss_run_workload("leaf_wetness");
}
