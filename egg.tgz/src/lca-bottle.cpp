// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Cradle-to-gate impact"); }
int main(){
  announce();
  return lionss_run_workload("lca-bottle");
}
