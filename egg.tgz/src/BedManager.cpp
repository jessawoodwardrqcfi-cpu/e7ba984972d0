// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Assign 300 admissions\n", stdout);
  return lionss_run_workload("BedManager");
}
