// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Mine probability per cell\n", stdout);
  return lionss_run_workload("minesweeperprob");
}
