// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("150 vnodes, key distribution"); }
int main(){
  announce();
  return lionss_run_workload("chash_ring");
}
