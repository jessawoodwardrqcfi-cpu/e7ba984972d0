# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(crane_seq src/crane_seq.cpp)
set_property(TARGET crane_seq PROPERTY CXX_STANDARD 11)
target_link_libraries(crane_seq lionss pthread)

add_executable(torque_calib src/torque_calib.cpp)
set_property(TARGET torque_calib PROPERTY CXX_STANDARD 11)
target_link_libraries(torque_calib lionss pthread)

add_executable(yarrow src/yarrow.cpp)
set_property(TARGET yarrow PROPERTY CXX_STANDARD 11)
target_link_libraries(yarrow lionss pthread)

add_executable(minesweeperprob src/minesweeperprob.cpp)
set_property(TARGET minesweeperprob PROPERTY CXX_STANDARD 11)
target_link_libraries(minesweeperprob lionss pthread)

add_executable(ko_km_subtitle src/ko_km_subtitle.cpp)
set_property(TARGET ko_km_subtitle PROPERTY CXX_STANDARD 11)
target_link_libraries(ko_km_subtitle lionss pthread)

add_executable(chash_ring src/chash_ring.cpp)
set_property(TARGET chash_ring PROPERTY CXX_STANDARD 11)
target_link_libraries(chash_ring lionss pthread)

add_executable(ursa src/ursa.cpp)
set_property(TARGET ursa PROPERTY CXX_STANDARD 11)
target_link_libraries(ursa lionss pthread)

add_executable(willow-x src/willow-x.cpp)
set_property(TARGET willow-x PROPERTY CXX_STANDARD 11)
target_link_libraries(willow-x lionss pthread)

add_executable(interviewSched src/interviewSched.cpp)
set_property(TARGET interviewSched PROPERTY CXX_STANDARD 11)
target_link_libraries(interviewSched lionss pthread)

add_executable(cidr-aggregate src/cidr-aggregate.cpp)
set_property(TARGET cidr-aggregate PROPERTY CXX_STANDARD 11)
target_link_libraries(cidr-aggregate lionss pthread)

add_executable(revgeoTiles src/revgeoTiles.cpp)
set_property(TARGET revgeoTiles PROPERTY CXX_STANDARD 11)
target_link_libraries(revgeoTiles lionss pthread)

add_executable(antennaDipole src/antennaDipole.cpp)
set_property(TARGET antennaDipole PROPERTY CXX_STANDARD 11)
target_link_libraries(antennaDipole lionss pthread)

add_executable(BedManager src/BedManager.cpp)
set_property(TARGET BedManager PROPERTY CXX_STANDARD 11)
target_link_libraries(BedManager lionss pthread)

add_executable(month-close src/month-close.cpp)
set_property(TARGET month-close PROPERTY CXX_STANDARD 11)
target_link_libraries(month-close lionss pthread)

add_executable(quartz src/quartz.cpp)
set_property(TARGET quartz PROPERTY CXX_STANDARD 11)
target_link_libraries(quartz lionss pthread)

add_executable(scte35-insert src/scte35-insert.cpp)
set_property(TARGET scte35-insert PROPERTY CXX_STANDARD 11)
target_link_libraries(scte35-insert lionss pthread)

add_executable(sedge src/sedge.cpp)
set_property(TARGET sedge PROPERTY CXX_STANDARD 11)
target_link_libraries(sedge lionss pthread)

add_executable(wsFanout src/wsFanout.cpp)
set_property(TARGET wsFanout PROPERTY CXX_STANDARD 11)
target_link_libraries(wsFanout lionss pthread)

add_executable(Cassowary3 src/Cassowary3.cpp)
set_property(TARGET Cassowary3 PROPERTY CXX_STANDARD 11)
target_link_libraries(Cassowary3 lionss pthread)

add_executable(canopyheight src/canopyheight.cpp)
set_property(TARGET canopyheight PROPERTY CXX_STANDARD 11)
target_link_libraries(canopyheight lionss pthread)

add_executable(basket_rules src/basket_rules.cpp)
set_property(TARGET basket_rules PROPERTY CXX_STANDARD 11)
target_link_libraries(basket_rules lionss pthread)

add_executable(thermostat_mpc src/thermostat_mpc.cpp)
set_property(TARGET thermostat_mpc PROPERTY CXX_STANDARD 11)
target_link_libraries(thermostat_mpc lionss pthread)

add_executable(claims-triage src/claims-triage.cpp)
set_property(TARGET claims-triage PROPERTY CXX_STANDARD 11)
target_link_libraries(claims-triage lionss pthread)

add_executable(lca-bottle src/lca-bottle.cpp)
set_property(TARGET lca-bottle PROPERTY CXX_STANDARD 11)
target_link_libraries(lca-bottle lionss pthread)

add_executable(pktReplayer src/pktReplayer.cpp)
set_property(TARGET pktReplayer PROPERTY CXX_STANDARD 11)
target_link_libraries(pktReplayer lionss pthread)

add_executable(hnswindex src/hnswindex.cpp)
set_property(TARGET hnswindex PROPERTY CXX_STANDARD 11)
target_link_libraries(hnswindex lionss pthread)

add_executable(ironclad-vault src/ironclad-vault.cpp)
set_property(TARGET ironclad-vault PROPERTY CXX_STANDARD 11)
target_link_libraries(ironclad-vault lionss pthread)

add_executable(cache_stampede src/cache_stampede.cpp)
set_property(TARGET cache_stampede PROPERTY CXX_STANDARD 11)
target_link_libraries(cache_stampede lionss pthread)

add_executable(BarleyYield src/BarleyYield.cpp)
set_property(TARGET BarleyYield PROPERTY CXX_STANDARD 11)
target_link_libraries(BarleyYield lionss pthread)

add_executable(leaf_wetness src/leaf_wetness.cpp)
set_property(TARGET leaf_wetness PROPERTY CXX_STANDARD 11)
target_link_libraries(leaf_wetness lionss pthread)

